
package poe_part2;

import javax.swing.JOptionPane;

public class TaskDetails {
    Task task = new Task();
    //These variables will hold the task details provided by the user.
    private static String task_name ; 
    private static int chosen_option;
    private static int number_of_tasks;
    private static int task_duration;
    private static int task_number; 
    private static String task_description; 
    private static String developer_names; 
    private static String task_status;   
    static int total_hours = 0; 
    static String task_details;

    // set and return the name of the task
    public void setTask_name(String name){
        task_name = name;
    }
    public String getTask_name(){
        return task_name;
    }
    
    // get the number selected by the user from the numeric options
    public int getChosenOPtion(){
        return chosen_option;
    }

    // set and return the number of tasks the user wishes to enter
    public void setNumber_of_tasks(int number){
        number_of_tasks = number;
    }
    public int getNumber_of_tasks(){
        return number_of_tasks;
    }
    
    // set and return the estimated duration of each task
    public void setTask_duration(int duration){
        task_duration = duration;
    }
    public int getTask_duration(){
        return task_duration;
    }
    
    //set and return a description of each chapter
    public void setTask_description(String description){
        task_description = description;
    }
    public String getTask_description(){
        return task_description;
    }
    
     // The user will be given a warning and a chance to re-enter the task description if it is longer than 50 words.
    public void DescriptionStatus(){
        while(!(task.checkTaskDescription(getTask_description())) ){
            JOptionPane.showMessageDialog(null,"Please enter a task description of not more than 50 characters");
            setTask_description(JOptionPane.showInputDialog("Please enter a task description"));
        }
       
        JOptionPane.showMessageDialog(null, "Task Successfully captured.");
    }

    
    // set and return the full names of the developer assigned to a task
    public void setDeveloper_names(String names){
        developer_names = names;
    }
    public String getDeveloper_names(){
        return developer_names;
    }
    
    
    
    public int welcomeAndChooseOption(boolean login){  
    /*
    The user is only welcomed to KanBan  if they logged in successfully.
    */    
        if(login){
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban\n");
            
            // the do-while loop will only stop if the user selects three from the numeric menu
            do{
                chosen_option = Integer.parseInt(JOptionPane.showInputDialog(
                        
                        "PLEASE SELECT AN OPTION\n"
                        + "Option 1) Add tasks\n"
                        + "Option 2) Show Report\n"
                        + "Option 3) Quit"));

                switch(chosen_option){
                    
                case 1: // if the user chooses 1, they will be allowed to add tasks.
                     
                    break;
                case 2: // this option tells the user the feature is still in development
                    JOptionPane.showMessageDialog(null, "Coming soon");
                    break;
                case 3: // this is the option that terminates the loop
                    chosen_option = 3;
                    break;
                
                }
            }
            while(chosen_option != 3);
            
        }
        return chosen_option;
    }

    
    //set and return the number of the current task
    public void setNumberOfCurrentTask(int task_number){
        this.task_number = task_number;
    }            
    public int getNumberOfCurrentTask(){
        return task_number;
    }
    
    /*
    Allow the user to choose the status of their task
    */
    public void setTaskStatus(){
        int option = Integer.parseInt(JOptionPane.showInputDialog("Please choose the Status of this task from the three options.\n"
                + "1) To Do\n"
                + "2) Doing\n"
                + "3) Done"));
        switch(option){
            case 1:
                task_status = "To Do";
                break;
            case 2:
                task_status = "Doing";
                break;
            case 3:
                task_status = "Done";
                break;
            default:
                task_status = "Invalid selection!! Please pick an option from the number from 1 to 3";
        }
    }
    
    public String getTask_status(){
        return task_status;
    }

    
    public void addTasks(){
    
        /*  get the number of tasks from the user and use it to control the loop that allows the user to add tasks
        */

        setNumber_of_tasks(Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you want to add")) );

        for(int i = 0; i < getNumber_of_tasks() ; i++){
         //Call all the othe setters

            setTaskStatus();
            setNumberOfCurrentTask(i);
            setTask_name(JOptionPane.showInputDialog("Enter task name "));
            setTask_duration(Integer.parseInt(JOptionPane.showInputDialog("Enter the duration of this task")));
            
            
            setDeveloper_names(JOptionPane.showInputDialog("Please enter the developer's first name and surname"));
            setTask_description(JOptionPane.showInputDialog("Please enter a task description"));
            DescriptionStatus();
            
            // Print out the Details of the task
            JOptionPane.showMessageDialog(null, task.printTaskDetails(getTask_status(), getDeveloper_names(), getNumberOfCurrentTask(), getTask_name(), getTask_description(), getTask_duration()));

            //Calculate the total number of hours needed to complete tasks.
            total_hours = total_hours + getTask_duration();


        }
        //Print out the total number of hours needed to complete all tasks.
    JOptionPane.showMessageDialog(null,"You need " + total_hours +" hours to complete these tasks.");

        
    }
    
    
}
