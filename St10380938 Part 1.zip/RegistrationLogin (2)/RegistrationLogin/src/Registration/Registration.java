
package Registration;

import java.util.Scanner;

public class Registration {
    
     static String firstName;
     static String userName;
     static String surname;
     static String password;
   
    public static void userDetails(){
        Scanner inforA = new Scanner(System.in);
        
        System.out.println("Please enter you first name");
        firstName = inforA.nextLine();
        System.out.println("Please enter your surname");
        surname = inforA.nextLine();
        System.out.println("Please enter your userName");
        userName = inforA.nextLine();
        System.out.println("Please enter your password");
        password = inforA.nextLine();
        
    }
    
 
    public static void main(String[] args) {
        userDetails();
        Login logObject = new Login();
        
        logObject.checkUserName();
        logObject.registerUser();
        System.out.println(logObject.returnLoginStatus());
        
    }
    
}
