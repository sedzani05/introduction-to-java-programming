
package Registration;
        
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.Test;

/**
 *
 * @author lab_services_student
 */
public class MassageTest {
    Message message = new Message();
    
    public MassageTest() {
    }

    @Test
    public void testGetMessage() {
        String expected = "I have arrived";
        string actual = message.getMessage();
        assertEquals(expected,actual);
    }

    /**
     * Test of getMassage method, of class Massage.
     */
    @Test
    public void testGetMassage() {
    }
    
}
